#!/usr/bin/env python
# coding: utf-8

# In[1]:
import numpy as np
import matplotlib.pyplot as plt
import numpy.linalg as na
import matplotlib.patches as patches 
import scipy.integrate as si
import sympy as sy  
import sympy.plotting as splot
import IPython.display as disp  
from matplotlib.patches import Polygon
from matplotlib.collections import PatchCollection
%matplotlib inline
sy.init_printing()
from Beam_module import *

L_m = int(input('Please write the length:')) 
t_mm = int(input('Please write the width: '))
P_N = 100e3  # load
wa_mm = int(input('Please write the width of А: '))  
wb_mm = int(input('Please write the width of B: '))  
E_Pa = 200e9  # elastic constant

x_m_array = np.linspace(0, L_m, 100 + 1) #Divide x range 0 ~ L into 100 intervals.
h_mm = (wb_mm - wa_mm) * x_m_array / L_m + wa_mm
plt.plot(x_m_array, h_mm, label='h(mm)') # First, indicate values for x & y
plt.ylim(ymin=0) # Set minimum of y value.
plt.xlabel('x(m)') # Set names for x, y axes.
plt.ylabel('h(mm)')
plt.grid(True) # Add grid to the plot.
plt.legend(loc=0) # Add legend.
plt.show() # Show plot.
# Plot area
X = 1e-3
A_m2 = t_mm * h_mm * (X**2)
plt.plot(x_m_array, A_m2, label='$A(m^2)$')
plt.ylim((0, plt.ylim()[-1]))  # y 축의 최소값을 0으로 지정한다
plt.xlabel('x(m)')
plt.ylabel('$A(m^2)$')
plt.grid(True)
plt.legend(loc=0)
plt.show()
# Pressure (load) graph
sigma_Pa = P_N / A_m2
plt.plot(x_m_array, sigma_Pa * 1e-6, label='$\sigma(MPa)$')
plt.ylim((0, plt.ylim()[-1]))  # y 축의 최소값을 0으로 지정한다
plt.xlabel('x(m)')
plt.ylabel('$\sigma(MPa)$')
plt.grid(True)
plt.legend(loc=0)
plt.show()
# Deformation graph
epsilon = sigma_Pa / E_Pa
plt.fill_between(x_m_array, epsilon)
plt.xlabel('x(m)')
plt.ylabel('$\epsilon$')
plt.grid(True)
plt.show()
delta_m = np.trapz(epsilon, x_m_array)

#Checking the correctness of the code
import IPython.display as disp
disp.Math(f"\delta = {delta_m:f}(m) = {delta_m*1000:f}(mm)")
assert(1e-5 > abs(delta_m*1000-3.433256))

#Concrete column (calculation)
A_bar_mm2 = int(input('The cross-sectional area of one beam:'))
n_bar = int(input('Number of bars:'))
P_N = 1000e3 # Compressive load
# Young's modules of steel and concrete
E_steel_Pa = 200e1
E_concrete_Pa = 14e9
w_mm = int(input('Enter the length of one side of a square concrete column:'))

X = 1e-3
A_bar_m2 = A_bar_mm2 * X**2
w_m = w_mm * X

disp.Math(f'X = {X}(m)')

disp.Math(f'A_{{bar}} = {A_bar_m2}(m^2)')
A_mat = np.matrix([[n_bar * A_bar_m2, w_m**2 - n_bar * A_bar_m2],
                   [1./E_steel_Pa, -1./E_concrete_Pa]])
A_mat
b_vec = np.matrix([[P_N],
                  [0.0]])
b_vec
sigma_Pa_mat = na.solve(A_mat, b_vec)
sigma_Pa_mat
disp.Math(f'\sigma_{{steel}} = {sigma_Pa_mat[0,0]:g}(Pa)' )
disp.Math(f'\sigma_{{concrete}} = {sigma_Pa_mat[1,0]:g}(Pa)' )
sigma_MPa_mat = sigma_Pa_mat * 1e-6
sigma_MPa_mat
P_steel_1_kN = sigma_Pa_mat[0] * A_bar_m2 * 1e-3
P_steel_1_kN
P_steel_4_kN = P_steel_1_kN * n_bar
P_steel_4_kN
P_concrete_kN = sigma_Pa_mat[1] * (w_m**2 - n_bar * A_bar_m2) * 1e-3
P_concrete_kN
float(P_steel_4_kN + P_concrete_kN)
zero_mat = A_mat * sigma_Pa_mat - b_vec
assert(1e-7 > abs(zero_mat[0, 0]))
assert(1e-7 > abs(zero_mat[1, 0]))
assert(1e-7 > (abs(float(P_steel_4_kN + P_concrete_kN) - P_N * 1e-3)))

#The second moment of inertia (the moment of inertia of the area)
import os
import sys

sys.path.append(os.path.abspath(os.path.join(os.pardir, 'utils')))
import draw_diagrams

draw_diagrams.rect_section()

b, h, y = sy.symbols('b, h, y', real=True)
I = sy.integrate(b * y**2, (y, -h/2, h/2))
I
#On the c coordinate and the parallel axes theorem
import draw_diagrams
draw_diagrams.rect_section_c()
b, h, c, y = sy.symbols('b, h, c, y', real=True)
I_C = sy.integrate(b * (y - c)**2, (y, -h/2, h/2))
I_C
assert True

#Bending stress
h_m = 200e-3

c_m = h_m * 0.5

y_m_array = np.linspace(-c_m, c_m, 6)
zeros_array = np.zeros_like(y_m_array)

sigma_max_Pa = 20000000.0

slope = - sigma_max_Pa / c_m
sigma_Pa_array = slope * y_m_array

plt.clf()
plt.grid(True)
plt.plot(zeros_array, y_m_array)
plt.plot(sigma_Pa_array, y_m_array)

for sigma_Pa, y_m in zip(sigma_Pa_array, y_m_array):
    plt.arrow(0.0, y_m,
             sigma_Pa*0.9, 0.0, head_width=1e-2, head_length=abs(sigma_Pa*.1))

plt.xlabel('$\\sigma$[Pa]')
plt.ylabel('$y$[m]')
plt.show()

#Code for building visual images of beams and the forces affecting it
plt.figure(figsize=(8,4))
rep_axis(scale=0.5, lineformat='y-')

rep_fix(0,0, scale=1, label='A', shw_label='left')
rep_none(10,0, scale=1, label='B', shw_label=True)
rep_element(0,10,-0.25, 0.25)
rep_leng(0,10,-0.25,-0.25, label='L', label_offset=(0,-0.25))
rep_vector(10, 0, 11.5, 0, offset=(0, 0.25), lineformat='b-', label='$P$', arrow_scale=0.15, aligned=True)
rep_vector(0, 0, -1.5, 0, offset=.2, lineformat='r-', label='$R_A$', arrow_scale=0.15)

plt.figure(figsize=(8,4))
rep_axis(scale=0.5, lineformat='y-')

rep_fix(0,0, scale=1, label='A', shw_label='left')
rep_none(10,0, scale=1, label='B', shw_label=True)
rep_element(0,6,-0.5, 0.5)
rep_element(6,10,-0.25, 0.25)
rep_leng(0,10,-0.25,-0.25, offset=-2, label='L', label_offset=(0,-0.25))
rep_leng(0,6,-0.25,-0.25, label='a', label_offset=(0,-0.25), arrow_scale=0.025)
rep_leng(6,10,-0.25,-0.25, label='b', label_offset=(0,-0.25), arrow_scale=0.038)
rep_vector(11.5, 0, 10, 0, offset=(0, 0.25), lineformat='b-', label='$P_1$', arrow_scale=0.15, aligned=True)
rep_vector(6, 0, 7, 0, offset=(0.2, 0.5), lineformat='b-', label='$P_2$', arrow_scale=0.15, aligned=True)
rep_vector(0, 0, -1.5, 0, offset=.2, lineformat='r-', label='$R_A$', arrow_scale=0.15)

plt.figure(figsize=(8,3))
rep_axis(scale=0.75, lineformat='y-')

rep_none(10,0, scale=1, label='B', shw_label=True, rotation=180)
rep_fix(0,0, scale=1, label='A', shw_label='right')
rep_element(0,10,-0.25, 0.25, fill=True)
rep_leng(0,10,-0.25,-0.25, label='L', label_offset=(0,-0.25))
rep_vector(10, 1.5, 10, 0.25, offset=(-0.25,0), lineformat='b-', label='$P$', arrow_scale=0.15)
rep_vector(0, -1.5, 0, -0.35, offset=-.20, lineformat='r-', label='$R_A$', arrow_scale=0.15)
rep_pair(0,0,0.5,70,240, lineformat='r-', label='$M_A$', label_offset=-0.3)